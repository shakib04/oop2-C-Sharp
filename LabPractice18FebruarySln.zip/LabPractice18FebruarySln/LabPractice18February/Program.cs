﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabPractice18February
{
    class Program
    {
        static void Main(string[] args)
        {
            Person p = new Person();

            Student s = new Student();

            p.M1();
            s.M1();

            Person p1 = new Student();
            p1.M1();

            //Student s2 = new Student(10, "Rakib", "B+",3.5);

            //Person pp = new Person(10, "Shakib", "B+");

            
        }
    }
}
