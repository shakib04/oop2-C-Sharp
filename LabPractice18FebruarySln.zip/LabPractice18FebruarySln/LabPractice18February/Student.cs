﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabPractice18February
{
    class Student:Person
    {
        private double cgpa;

        internal double Cgpa
        {
            get { return this.cgpa; }
            set { this.cgpa = value; }
        }

        internal Student(int id, string name, string bloodGroup, double cgpa) : base(id,name,bloodGroup)
        {
            //base.Id = id;
            //base.Name = name;
            //base.BloodGroup = bloodGroup;
            this.Cgpa = cgpa;
        }

        internal override void M1()
        {
            Console.WriteLine("Student M1");
        }

        internal void M2()
        {
            Console.WriteLine("Student M2");
        }

        internal override void ShowInfo()
        {
            base.ShowInfo();
            Console.WriteLine("CGPA: {0}", Cgpa);
        }

        internal Student() : base()
        {
            //Console.WriteLine("Student");
        }

        internal Student(int a) : base(a)
        {
            //Console.WriteLine("Student I " + a);
        }
    }
}
