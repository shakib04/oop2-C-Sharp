﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppStruct
{
    class Program
    {
        private static void Main(string[] args)
        {
            /*
            Address addressOne;
            //addressOne.houseNo = 54;
            //addressOne.roadNo = 102;
            //addressOne.postalCode = 2100;
            //addressOne.district = "Dhaka";
            //addressOne.PrintAddress();

            Address addressTwo = new Address(23, 28, 1212, "Sylhet");
            addressTwo.PrintAddress();

            addressOne = addressTwo;
            */
            //int x = 100;
            //Address addressOne = new Address(12, 32, 1200, "Dhaka");
            //Student s1 = new Student(100, "Bruce", new Address(12, 32, 1200, "Dhaka"));
            //s1.ShowStudentInfo();

            Student[] students = new Student[3];
            //students[0] = new Student(100, "Bruce", new Address(12, 32, 1200, "Dhaka")); //object of student class
            //students[1] = new Student(200, "Shakib", new Address(72, 32, 1200, "Dhaka"));

            //byte t = 0;
            //while (t < students.Length)
            //{
            //    students[t] = new Student();
            //}

            students[2] = new Student();
            students[2].SetName("Shakib");
            students[2].SetId(400);
            students[2].SetAddress(new Address(72, 32, 1200, "Dhaka"));

            students[2].ShowStudentInfo();

            students[2].Name = "Rakib"; //set value usinng property // left part ofassignment operator
            string z = students[2].Name; //get value using property
        }
    }
}
