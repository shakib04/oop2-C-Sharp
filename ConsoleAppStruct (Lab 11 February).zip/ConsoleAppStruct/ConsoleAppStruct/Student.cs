﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppStruct
{
    struct Address
    {
        private byte houseNo;
        private byte roadNo;
        private ushort postalCode;
        private string district;

        public Address(byte houseNo, byte roadNo, ushort postalCode, string district)
        {
            this.houseNo = houseNo;
            this.roadNo = roadNo;
            this.postalCode = postalCode;
            this.district = district;
        }

        public void PrintAddress()
        {
            Console.WriteLine("{0}", this.houseNo);
            Console.WriteLine("{0}", this.roadNo);
            Console.WriteLine("{0}", this.postalCode);
            Console.WriteLine("{0}", this.district);
        }
    }

    class Student
    {
        private int id;
        private string name;
        private Address studentAddress;

        public string Name //no paranthesis //property 
        {
            get { return this.name; }
            set { this.name = value; }
        }

        public int Id
        {
            get { return this.id; }
            set {
 
                this.id = value; }
        }

        public Address StudentAddress
        {
            get { return this.studentAddress; }
            set { this.studentAddress = value; }
        }

        public int GetId()
        {
            return this.id;
        }

        public void SetId(int id)
        {
            if(id >=100)
            {
                this.id = id;
            }

            else
                this.id = -1;
            
        }

        public string GetName()
        {
            return this.name;
        }

        public void SetName(string name)
        {
            this.name = name;
        }

        public Address GetAddress()
        {
            return this.studentAddress;
        }

        public void SetAddress(Address studentAddress)
        {
            this.studentAddress = studentAddress;
        }

        public Student() //default constructor
        {
        }

        public Student(int id, string name, Address studentAddress)
        {
            this.Id = id;//this.SetId(id); //this.id = id;  //helps to reduce code writing
            this.Name = name;//this.SetName(name); // this.name = name;
            this.StudentAddress = studentAddress; //this.SetAddress(studentAddress); //this.studentAddress = studentAddress;
        }

        public void ShowStudentInfo()
        {
            Console.WriteLine("Student's Information\n------------------");
            Console.WriteLine("Student's ID: {0}", this.Id); //this.id // this.GetId()
            Console.WriteLine("Student's Name: {0}", this.GetName()); //this.name
            Console.WriteLine("Student's Address");
            this.GetAddress().PrintAddress();   //this.studentAddress.PrintAddress();
        }
    }
}
