﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeInfoWithTax
{
   abstract internal class Employee
    {
        private string id;
        private string name;
        private double salary;

        internal string Id
        {
            get{return this.id;}
            set{this.id = value;}
        }

        internal string Name
        {
            set{this.name = value;}
            get{return this.name;}
        }

        internal double Salary
        {
            set{this.salary = value;}
            get{return this.salary;}
        }

        internal Employee(string id, string name, double salary)
        {
            this.Id = id;
            this.Name = name;
            this.Salary = salary;
        }

       

        internal abstract void TexCalculate();

        internal virtual void EmployeeInfo()
        {
            Console.WriteLine("Employee Id: {0}", this.Id);
            Console.WriteLine("Name: {0}", this.Name);
            Console.WriteLine("Salary: {0}", this.Salary);
        }
    }
}
