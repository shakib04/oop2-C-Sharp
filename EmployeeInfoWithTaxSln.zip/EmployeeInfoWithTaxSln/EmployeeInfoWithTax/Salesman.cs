﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeInfoWithTax
{
    class Salesman:FullTimeEm
    {
        private double commission;

        internal double Commission
        {
            set { this.commission = value; }
            get { return this.commission; }
        }

        internal Salesman(string id, string name, double salary, double bonus, double commission):base(id,name,salary,bonus)
        {
            this.Commission = commission;
        }

        internal override void TexCalculate()
        {

            double tax = ((base.Salary / 2) * 0.10 + this.Bonus * 0.08+ this.Commission * 0.05);
            Console.WriteLine("Salesman Tax: {0}", tax);
        }
    }
}
