﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeInfoWithTax
{
    class FullTimeEm:Employee
    {
        private double bonus;

        internal double Bonus
        {
            set { this.bonus = value; }
            get { return this.bonus; }
        }

        internal FullTimeEm(string id, string name, double salary,double bonus) : base(id,name,salary)
        {
            this.Bonus = bonus;
        }

        internal override void TexCalculate()
        {
            
            double tax = ((base.Salary / 2)* 0.10 + this.Bonus * 0.08);
            Console.WriteLine("Full Time Employee Tax: {0}",tax);
        }
    }
}
