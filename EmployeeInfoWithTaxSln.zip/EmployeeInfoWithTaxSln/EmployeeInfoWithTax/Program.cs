﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeInfoWithTax
{
    class Program
    {
        static void Main(string[] args)
        {
            //Employee em = new FullTimeEm("101", "Shakib", 100000, 8000);
            //em.TexCalculate();

            Employee em2 = new PartTimeEm("102", "SSS", 20000);
            em2.EmployeeInfo();

            //Employee em3 = new Salesman("103", "AAA", 50000, 1000, 1000);
            //em3.TexCalculate();

            //Employee em4 = new ExecutiveEm("104", "BBB", 10000, 3000);
            //em4.TexCalculate();

            //Employee em2 = new Employee("", "", 100);
            //em2.TexCalculate();
        }
    }
}
