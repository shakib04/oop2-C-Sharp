﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeInfoWithTax
{
    class ExecutiveEm:FullTimeEm
    {

        internal ExecutiveEm(string id, string name, double salary, double bonus)
            : base(id, name, salary, bonus)
        {

        }

        internal override void TexCalculate()
        {

            double tax = ((base.Salary / 2) * 0.10 + base.Bonus * 0.08);
            Console.WriteLine("Executive Tax: {0}", tax);
        }
    }
}
