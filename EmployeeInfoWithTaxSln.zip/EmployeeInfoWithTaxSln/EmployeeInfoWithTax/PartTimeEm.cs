﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeInfoWithTax
{
    class PartTimeEm:Employee
    {
        internal PartTimeEm(string id, string name, double salary)
            : base(id, name, salary)
        {

        }


        internal override void TexCalculate()
        {

            double tax = ((base.Salary / 2) * 0.10);
            Console.WriteLine("Part Time Employee Tax: {0}", tax);
        }

        internal override void EmployeeInfo()
        {
            Console.WriteLine("///Parttime Employee///");
            base.EmployeeInfo();
            this.TexCalculate();
        }
    }
}
