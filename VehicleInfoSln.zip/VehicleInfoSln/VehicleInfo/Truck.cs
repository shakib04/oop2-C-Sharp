﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleInfo
{
    class Truck:Vehicle
    {
        private int loadCapasity;

        internal int LoadCapasity
        {
            get { return this.loadCapasity; }
            set { this.loadCapasity = value; }
        }

        internal Truck(int loadCapasity,string chesisNo, RegistrationDate rg) : base(chesisNo,rg)
        {
            this.LoadCapasity = loadCapasity;
        }

        internal override void ShowInfo()
        {
            base.ShowInfo();
            Console.WriteLine("Load Capasity: {0}", LoadCapasity);
        }


    }
}
