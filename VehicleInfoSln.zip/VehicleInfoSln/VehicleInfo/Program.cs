﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleInfo
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Truck Info");
            Truck t = new Truck(100,"001",new RegistrationDate(21,"June",2009));
            t.ShowInfo();

            Console.WriteLine("-------");

            Console.WriteLine("Car Info");

            Car c = new Car("001", new RegistrationDate(21, "June", 2009), 20);
            c.ShowInfo();
        }
    }
}
