﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleInfo
{
    struct RegistrationDate
    {
        private byte myDay;
        private string myMonth;
        private int myYear;

        public RegistrationDate(byte myDay, string myMonth, int myYear)
        {
            this.myDay = myDay;
            this.myMonth = myMonth;
            this.myYear = myYear;
        }

        public void ShowInfo()
        {
            Console.WriteLine("Date: {0}", myDay);
            Console.WriteLine("Month: {0}", myMonth);
            Console.WriteLine("Year: {0}", myYear);
        }


    }
    class Vehicle
    {
        private string chesisNo;

        RegistrationDate rg = new RegistrationDate();

        //private int noOfPassergers;
        //private int loa

        internal Vehicle()
        {
        }

        internal string Chesisno
        {
            get{return this.chesisNo;}
            set{this.chesisNo = value;}
        }

        internal RegistrationDate Rg
        {
            get { return this.rg; }
            set { this.rg = value; }
        }

        internal Vehicle(string chesisNo, RegistrationDate rg)
        {
            this.Chesisno = chesisNo;
            this.Rg = rg;
        }

        internal virtual void ShowInfo()
        {
            Console.WriteLine("Chesis No: {0}", Chesisno);
            rg.ShowInfo();
            //Console.WriteLine("Registration Date: {0}", Rg);
        }




    }
}
