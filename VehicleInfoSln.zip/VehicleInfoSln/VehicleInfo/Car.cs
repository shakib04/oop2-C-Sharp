﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleInfo
{
    class Car:Vehicle
    {
        private int noOfPassenger;

        internal int NoOfPassenger
        {
            get { return this.noOfPassenger; }
            set { this.noOfPassenger = value; }
        }

        internal Car(string chesisNo, RegistrationDate rg, int noOfPassenger)
            : base(chesisNo, rg)
        {
            this.NoOfPassenger = noOfPassenger;
        }

        internal override void ShowInfo()
        {
            base.ShowInfo();
            Console.WriteLine("No of Passenger: {0}", NoOfPassenger);
        }
    }
}
