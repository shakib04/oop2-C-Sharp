﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAccountMng
{
    class Program
    {
        static void Main(string[] args)
        {
            Account[] accounts = new Account[4];
            accounts[0] = new Savings("Bruce", new DateTime(2018, 9, 13), 4000, 5);
            //accounts[0].Deposit(500);
            //accounts[0].Withdraw(4001);
            //accounts[0].ShowInfo();

            accounts[1] = new Current("Clerk", new DateTime(2018, 10, 03), 3500);
            //accounts[1].Deposit(500);
            //accounts[1].ShowInfo();
            //accounts[1].Withdraw(3000);
            //accounts[1].ShowInfo();
            //accounts[2] = new Savings("Tony", new DateTime(2017, 9, 23), 6600, 3);
            //accounts[2].ShowInfo();

            Account.Transfer(accounts[0], accounts[1], 1000);
            accounts[0].ShowInfo();

            //Bank.AddAccount(accounts[0]);
            //Bank.AddAccount(accounts[1]);
            //Bank.ShowAll();

            Bank.SearchIndividualAccount("A-100-S");
            Bank.DeleteAccount("A-100-Sc");
        }
    }
}
