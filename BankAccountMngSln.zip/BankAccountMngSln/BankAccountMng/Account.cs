﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAccountMng
{
    class Account
    {
        private string id;
        //private string name;
        //private double balance;
        private static int serialNumber = 100;
        //private DateTime dt;

        internal Account(string name, double balance, DateTime dt)
        {
            this.Id = (serialNumber++).ToString("000");
            this.Name = name;
            this.Balance = balance;
            this.Dt = dt;
        }

        internal DateTime Dt
        {
            get;
            set;
        }

        internal virtual string Id
        {
            get { return this.id; }
            set { this.id = "A-"+value; }
        }

        internal string Name
        {
           get;
           set;
        }

        internal double Balance
        {
            get;
            set;
        }

        internal virtual double Deposit(double balance)
        {
            return 0;
        }

        internal virtual double Withdraw(double balance)
        {
            return 0;
        }

        internal static void Transfer(Account acc1, Account acc2, double amount)
        {
            acc1.Balance =  acc1.Balance - amount;
            acc2.Balance = acc1.Balance + amount;
        }

        internal virtual void ShowInfo()
        {
            Console.WriteLine("Name: {0}",this.Name);
            Console.WriteLine("ID: {0}",this.Id);
            Console.WriteLine("Balance: {0}",this.Balance);
            Console.WriteLine("Registration Date: {0}",this.Dt);

        }


    }
}
