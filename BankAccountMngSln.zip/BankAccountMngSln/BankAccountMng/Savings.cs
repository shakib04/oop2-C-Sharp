﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAccountMng
{
    class Savings:Account
    {
        private int duration;

        internal Savings(string name, DateTime dt, double balance,int duration):base(name,balance,dt)
        {
            this.Duration = duration;
        }

        internal int Duration
        {
            get{return this.duration;}

            set
            {
                if (this.duration <= 2)
                {
                    this.duration = value;
                }

                else
                { this.duration = -2; }
            }
        }

        internal override string Id
        {
            set
            {
                base.Id = value + "-S";
            }
        }

        internal override double Deposit(double balance)
        {
            return base.Balance = base.Balance + balance;
            
        }


        internal override double Withdraw(double balance)
        {
            //return base.Withdraw(balance);

            if (balance < 3000)
            {
                if (base.Balance >= balance)
                {
                    return base.Balance = base.Balance - balance;
                }

                else
                {
                    Console.WriteLine("Amount more than balance.");
                    return base.Balance;
                }
            }

            else
            {
                Console.WriteLine("More than 3000 not posibble for 1 time.");
                return base.Balance;
            }
        }

        internal override void ShowInfo()
        {
            base.ShowInfo();
            Console.WriteLine("Duration: {0}",this.Duration);
        }
    }
}
