﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAccountMng
{
    class Current:Account
    {
        private double minBalace = 500;

        internal Current(string name, DateTime dt, double balance)
            : base(name, balance, dt)
        {

        }

        internal override string Id
        {
            set
            {
                base.Id = value+"-C";
            }
        }

        internal override double Deposit(double balance)
        {
            return base.Balance = base.Balance + balance;
        }

        internal override double Withdraw(double balance)
        {
            if ((base.Balance - minBalace) >= balance)
            {
                return base.Balance = base.Balance - balance;
            }

            else
            {
                Console.WriteLine("Invalid Amount");
                return base.Balance;
            }
        }

       

        internal override void ShowInfo()
        {
            base.ShowInfo();
        }


    }
}
