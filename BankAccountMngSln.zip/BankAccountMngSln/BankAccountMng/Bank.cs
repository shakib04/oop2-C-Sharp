﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAccountMng
{
    class Bank
    {
        private static Account[] accounts = new Account[1000];
        private static int count = 0;


        internal static void AddAccount(Account account)
        {
            accounts[count] = account;
            count++;
        }

        internal static void ShowAll()
        {
            short index = 0;

            while (index < count)
            {
                accounts[index].ShowInfo();
                Console.WriteLine();
                index++;
            }
        }

        internal static bool SearchIndividualAccount(string key)
        {
            short index = 0;
            while (index < count)
            {
                if (accounts[index].Id.Equals(key))
                {
                    Console.WriteLine("Found");
                    accounts[index].ShowInfo();
                    return true;
                }

                index++;
            }
                {
                    Console.WriteLine("Not Found");
                    return false;
                }
        }

        internal static bool DeleteAccount(string key)
        {
            short index = 0;
            while (index < count)
            {
                if (accounts[index].Id.Equals(key))
                {
                    accounts[index] = null;
                    Console.WriteLine("Deleted.");
                    return true;
                   
                }
                index++;
            }


            Console.WriteLine("Not Found");
            return false;
        }




    }
}
